Tip Calculator - JavaFX

Requirements:
- JDK 17 or later
- Maven installed

Run:
1. Extract the ZIP file.
2. Open a terminal in the extracted TipCalculatorJavaFX folder.
3. Run: mvn clean javafx:run

Files:
- tip_calculator.fxml: UI layout
- TipCalculatorController.java: calculation, validation, and reset logic
- TipCalculatorApp.java: JavaFX application entry point
- pom.xml: Maven build configuration

Example:
Bill Amount = 50
Tip Percentage = 15
Result = Tip Amount: $7.50
